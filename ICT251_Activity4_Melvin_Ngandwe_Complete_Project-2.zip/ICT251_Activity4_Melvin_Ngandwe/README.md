# ICT251 Activity 4 — Question 13: Science Fair Projects
**Student:** Melvin Ng’andwe  
**Student ID:** 202510639

A single-table CRUD application using Node.js, Express, SQLite, HTML, CSS, and JavaScript.

## Features
- One `projects` table with a primary key and seven additional columns.
- Ten sample records inserted automatically when the table is empty.
- GET all, GET by ID, POST, PUT, and DELETE REST endpoints.
- Frontend for creating, listing, editing, and deleting projects.
- JSON responses, input validation, CORS, and environment configuration.
- Postman collection included in `postman/`.

## Run locally
Install Node.js 20 or newer. From the `backend` folder run:
1. `npm install`
2. `npm start`
3. Open `http://localhost:3000`
4. API: `http://localhost:3000/api/projects`
5. Health check: `http://localhost:3000/api/health`

## API paths
- `GET /api/projects`
- `GET /api/projects/:id`
- `POST /api/projects`
- `PUT /api/projects/:id`
- `DELETE /api/projects/:id`
- `GET /api/health`

POST/PUT JSON body:
```json
{
  "project_title": "Solar Water Heater",
  "student_name": "Example Student",
  "category": "Renewable Energy",
  "description": "Test a low-cost solar water heating design.",
  "status": "Proposed"
}
```
Allowed statuses: `Proposed`, `In Progress`, `Completed`.

## Render deployment
Upload this project to a GitHub repository that you own or have permission to edit. In Render, create a Blueprint using `render.yaml`, or configure a Web Service with root directory `backend`, build command `npm install`, and start command `npm start`. The YAML requests a persistent disk for SQLite at `/var/data`; availability depends on your Render plan. After deployment, verify `/api/health` and `/api/projects` before submitting the URL.

## Evidence
Import `postman/ICT251_Science_Fair_API.postman_collection.json` in Postman and change `baseUrl` to the deployed URL. Test GET all, GET by ID, POST, PUT, and DELETE. Capture genuine screenshots or the required video from the running system. Do not fabricate evidence or claim the app is live before checking it.
