require("dotenv").config();
const express = require("express");
const cors = require("cors");
const path = require("path");
const Database = require("better-sqlite3");
const app = express();
const PORT = Number(process.env.PORT || 3000);
app.use(cors());
app.use(express.json({limit:"1mb"}));
app.use(express.static(path.join(__dirname,"..","frontend")));
const db = new Database(process.env.DB_PATH || path.join(__dirname,"science_fair.db"));
db.pragma("journal_mode = WAL");
db.exec(`CREATE TABLE IF NOT EXISTS projects(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 project_title TEXT NOT NULL, student_name TEXT NOT NULL, category TEXT NOT NULL,
 description TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'Proposed'
 CHECK(status IN ('Proposed','In Progress','Completed')),
 created_at TEXT NOT NULL DEFAULT (datetime('now')),
 updated_at TEXT NOT NULL DEFAULT (datetime('now')))`);
if (db.prepare("SELECT COUNT(*) n FROM projects").get().n===0) {
 const ins=db.prepare("INSERT INTO projects(project_title,student_name,category,description,status) VALUES(?,?,?,?,?)");
 const rows=[
 ["Solar-Powered Phone Charger","Chanda Phiri","Renewable Energy","A solar panel charges a USB power bank.","Proposed"],
 ["Water Filtration Using Sand","Bwalya Tembo","Environmental Science","Compare water clarity before and after filtration.","In Progress"],
 ["Smart Plant Watering","Mwamba Zulu","Engineering","A moisture sensor controls a small water pump.","Proposed"],
 ["Biodegradable Plastic from Starch","Ruth Banda","Chemistry","Test starch-based film as alternative packaging.","Completed"],
 ["Rainwater Collection Model","Peter Lungu","Environmental Science","Demonstrate rooftop collection and storage.","In Progress"],
 ["Miniature Wind Turbine","Natasha Chileshe","Renewable Energy","Measure voltage at different fan speeds.","Proposed"],
 ["Fruit Battery Experiment","Kelvin Mwila","Physics","Compare voltage from different fruits.","Completed"],
 ["Soil Moisture Meter","Grace Musonda","Agriculture","Build a circuit to estimate soil moisture.","In Progress"],
 ["Natural Indicators from Flowers","Thandiwe Soko","Chemistry","Test flower extracts with household acids and bases safely.","Proposed"],
 ["Insulated Solar Oven","Brian Mumba","Renewable Energy","Compare heating performance of reflective materials.","Completed"]];
 const tx=db.transaction(a=>a.forEach(r=>ins.run(...r))); tx(rows);
}
const statuses=new Set(["Proposed","In Progress","Completed"]);
const fields=["project_title","student_name","category","description"];
function validate(b){
 if(!b||typeof b!=="object"||Array.isArray(b))return "Request body must be a JSON object.";
 for(const f of fields)if(typeof b[f]!=="string"||!b[f].trim())return `${f} is required and must be text.`;
 if(b.status!==undefined&&!statuses.has(b.status))return "status must be Proposed, In Progress, or Completed.";
 return null;
}
function payload(b){return {...Object.fromEntries(fields.map(f=>[f,b[f].trim()])),status:b.status||"Proposed"}}
function idOf(v){const n=Number(v);return Number.isInteger(n)&&n>0?n:null}
function missing(res){return res.status(404).json({error:"Project not found."})}
app.get("/api/health",(req,res)=>res.json({status:"ok",service:"ICT251 Science Fair Projects API"}));
app.get("/api/projects",(req,res)=>{const data=db.prepare("SELECT * FROM projects ORDER BY id").all();res.json({count:data.length,data})});
app.get("/api/projects/:id",(req,res)=>{const id=idOf(req.params.id);if(!id)return res.status(400).json({error:"ID must be a positive integer."});const data=db.prepare("SELECT * FROM projects WHERE id=?").get(id);if(!data)return missing(res);res.json({data})});
app.post("/api/projects",(req,res)=>{const e=validate(req.body);if(e)return res.status(400).json({error:e});const b=payload(req.body);const r=db.prepare("INSERT INTO projects(project_title,student_name,category,description,status) VALUES(@project_title,@student_name,@category,@description,@status)").run(b);const data=db.prepare("SELECT * FROM projects WHERE id=?").get(r.lastInsertRowid);res.status(201).json({message:"Project created successfully.",data})});
app.put("/api/projects/:id",(req,res)=>{const id=idOf(req.params.id);if(!id)return res.status(400).json({error:"ID must be a positive integer."});if(!db.prepare("SELECT id FROM projects WHERE id=?").get(id))return missing(res);const e=validate(req.body);if(e)return res.status(400).json({error:e});const b=payload(req.body);db.prepare("UPDATE projects SET project_title=@project_title,student_name=@student_name,category=@category,description=@description,status=@status,updated_at=datetime('now') WHERE id=@id").run({...b,id});res.json({message:"Project updated successfully.",data:db.prepare("SELECT * FROM projects WHERE id=?").get(id)})});
app.delete("/api/projects/:id",(req,res)=>{const id=idOf(req.params.id);if(!id)return res.status(400).json({error:"ID must be a positive integer."});const r=db.prepare("DELETE FROM projects WHERE id=?").run(id);if(!r.changes)return missing(res);res.json({message:`Project ${id} deleted successfully.`})});
app.use("/api",(req,res)=>res.status(404).json({error:"API endpoint not found."}));
app.listen(PORT,()=>console.log(`Science Fair app running on port ${PORT}`));
