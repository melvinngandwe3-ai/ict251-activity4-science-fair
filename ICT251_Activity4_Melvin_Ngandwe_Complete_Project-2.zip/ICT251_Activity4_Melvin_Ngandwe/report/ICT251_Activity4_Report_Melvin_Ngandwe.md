# ICT251 ACTIVITY 4
## Single-Table CRUD Application Using Node.js
### Question 13 — Science Fair Projects

**Student Name:** Melvin Ng’andwe  
**Student ID:** 202510639  
**Course:** ICT251 — Web Technologies  
**Project Topic:** Question 13 — Science Fair Projects

## 1. Introduction
This project is a browser-based register for science fair projects. It uses Node.js and Express to provide a REST API, SQLite for data storage, and HTML, CSS, and JavaScript for the user interface. The application supports Create, Read, Update, and Delete (CRUD) operations. API responses are returned as JSON.

## 2. Objectives
- Create one database table with a primary key and at least five additional fields.
- Seed the database with at least ten sample science fair projects.
- Implement GET all, GET by ID, POST, PUT, and DELETE endpoints.
- Build a browser interface to add, list, edit, and delete projects.
- Validate request data and return meaningful HTTP status codes.
- Test the API using Postman and prepare genuine evidence.

## 3. Tools and Technologies
- **Node.js:** JavaScript runtime for the backend.
- **Express:** Handles HTTP routes and JSON requests and responses.
- **SQLite / better-sqlite3:** Stores the single `projects` table.
- **HTML, CSS, JavaScript:** Builds the browser frontend.
- **Postman:** Used for manual API testing.

## 4. Database Design
The application uses one table named `projects`. The database and table are created automatically when the server starts. Ten sample records are inserted when the table is empty.

| Field | Type | Purpose |
|---|---|---|
| `id` | INTEGER | Primary key; auto-increment |
| `project_title` | TEXT | Required project title |
| `student_name` | TEXT | Required student name |
| `category` | TEXT | Project category |
| `description` | TEXT | Project description |
| `status` | TEXT | Proposed, In Progress, or Completed |
| `created_at` | TEXT | Record creation timestamp |
| `updated_at` | TEXT | Last update timestamp |

## 5. REST API Endpoints
| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/projects` | Returns all projects as JSON |
| GET | `/api/projects/:id` | Returns one project |
| POST | `/api/projects` | Creates a project; returns HTTP 201 |
| PUT | `/api/projects/:id` | Updates an existing project |
| DELETE | `/api/projects/:id` | Deletes a project |
| GET | `/api/health` | Confirms the service is responding |

## 6. Frontend Features
The page displays projects in a table and shows the record count. A form creates new records. The Edit action loads a selected record into the form and saves changes through PUT. The Delete action requests confirmation and calls DELETE. The list refreshes after successful changes.

## 7. Validation and Error Handling
The API checks that required text fields are present and non-empty. Status must be Proposed, In Progress, or Completed. Invalid IDs and invalid input return HTTP 400. Requests for missing records return HTTP 404. Unknown API routes return HTTP 404 with a JSON error message.

## 8. Testing Plan and Evidence
Import `postman/ICT251_Science_Fair_API.postman_collection.json` into Postman and set `baseUrl` to the local or deployed application URL. Test GET all, GET by ID, POST a temporary project, PUT the temporary project, and DELETE the temporary project. Capture genuine screenshots showing the HTTP method, URL, request body where applicable, status code, and JSON response. If the course requires a video, record the test sequence from the running system.

## 9. Running the Application
From the `backend` folder, run `npm install` and then `npm start`. Open `http://localhost:3000` for the frontend, or `http://localhost:3000/api/projects` for the JSON endpoint. The `.env.example` file documents environment variables. The application can be deployed to Render using the included `render.yaml`, subject to the selected plan's persistent-disk availability.

## 10. Deployment and Submission Checklist
- [ ] Upload project files to a GitHub repository the student owns or can edit.
- [ ] Deploy the service and verify `/api/health`.
- [ ] Verify `/api/projects` returns JSON with at least ten records.
- [ ] Complete all five CRUD endpoint tests in Postman.
- [ ] Capture genuine Postman screenshots/video.
- [ ] Submit the live frontend/API URL and any required form response.

**Status note:** This report describes the included implementation and testing procedure. It does not claim that deployment or live endpoint testing has already succeeded. Live links and evidence should be added only after verification.
